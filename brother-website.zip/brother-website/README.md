# For my elder brother

A small gift website: brother-sister quotes, photos, a year-by-year story, a quiz, a message, and a box to write back.

## Files
- `index.html` is the whole website (photos are inside it). No build step needed.

## Put it on GitHub
1. On github.com, tap **New repository**. Name it, for example, `brother-website`.
2. Tap **uploading an existing file** and upload `index.html` and `README.md`.
   (GitHub does not open zip files, so unzip first and upload the files inside.)
3. Tap **Commit changes**.

## Make it live (pick one)
**GitHub Pages**
1. In the repository, open **Settings > Pages**.
2. Under **Build and deployment**, choose **Deploy from a branch**, then branch **main** and folder **/ (root)**. Save.
3. After a minute your site is at `https://YOUR-USERNAME.github.io/brother-website/`.

**Vercel**
1. Sign in at vercel.com with GitHub.
2. Tap **Add New > Project**, pick this repository, and tap **Deploy**.
